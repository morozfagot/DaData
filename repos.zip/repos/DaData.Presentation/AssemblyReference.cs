﻿namespace DaData.Presentation
{
    public static class AssemblyReference
    {
    }
}
