﻿using DaData.Application.Abstractions.Messaging;

namespace DaData.Application.Address.Queries.ParseAddresses
{
    public record FullAddressQuery(Guid Id, string addressForStandardization) : IQuery<FullAddressDto>
    {
    }
}
