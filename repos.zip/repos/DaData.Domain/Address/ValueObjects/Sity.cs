﻿namespace DaData.Domain.Address.ValueObjects
{
    public record Sity(string Value);
}
