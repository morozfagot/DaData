﻿namespace DaData.Domain.Address.ValueObjects
{
    public record Street(string value);
}
