﻿namespace DaData.Domain.Address.ValueObjects
{
    public record Region(string Value);
}
