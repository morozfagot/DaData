﻿namespace DaData.Domain.Address.ValueObjects
{
    public record Country(string Value);
}
