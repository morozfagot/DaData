﻿namespace DaData.Domain.Address
{
    public class DaDatakeys
    {
        public string Token { get; set; }
        public string Secret { get; set; }
    }
}
