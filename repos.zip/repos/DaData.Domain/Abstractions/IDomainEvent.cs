﻿using MediatR;

namespace DaData.Domain.Abstractions
{
    public interface IDomainEvent : INotification
    {
    }
}
